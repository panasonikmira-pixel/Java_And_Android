package com.example.dzmobile1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public class Main {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            System.out.print("Podaj imię: ");
            String imie = sc.nextLine().trim();

            System.out.print("Podaj nazwisko: ");
            String nazwisko = sc.nextLine().trim();

            System.out.print("Podaj email: ");
            String email = sc.nextLine().trim();

            System.out.print("Podaj haslo: ");
            String haslo = sc.nextLine().trim();

            if(imie.isEmpty() || nazwisko.isEmpty() || email.isEmpty() || haslo.isEmpty()){
                System.out.println("Uzupełnij wszystkie pola!!!");
            };
            boolean zawiera;
            if (email.contains("@") && email.contains(".")) {
                zawiera = true;
            } else {
                System.out.println("Podaj poprawny adres email!!");
            };

            if (haslo.length() < 8 || !haslo.matches(".*[A-Z].*") || !haslo.matches(".*[a-z].*") || !haslo.matches(".*[!@#$%^&*()_+{}?;':<>,./\\-=].*")) {
                System.out.println("Hasło musi mieć co najmniej 8 znaków, dużą i małą literę oraz znak specjalny!!!");
            }
            System.out.println("Dane są prawidłowe");

        };
    };
}