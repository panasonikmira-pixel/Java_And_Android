package com.example.dicegame;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText editTextLiczbaKostek;
    private Button buttonLosuj;
    private Button buttonRosnaco;
    private Button buttonMalejaco;
    private GridLayout gridKostki;
    private TextView textViewWyniki;

    private ArrayList<Integer> listaWynikow;

    private  int[] image;
    private Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextLiczbaKostek = findViewById(R.id.editTextLiczbaKostek);
        buttonLosuj = findViewById(R.id.buttonLosuj);
        buttonRosnaco = findViewById(R.id.buttonRosnaco);
        buttonMalejaco = findViewById(R.id.buttonMalejaco);
        gridKostki = findViewById(R.id.gridKostki);
        textViewWyniki = findViewById(R.id.textViewWyniki);

        image = new int[]{R.drawable.kostka_1,R.drawable.kostka_2,R.drawable.kostka_3,R.drawable.kostka_4,R.drawable.kostka_5,R.drawable.kostka_6};
        listaWynikow = new ArrayList<>();
        random = new Random();

        buttonLosuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wykonajLosowanie();
            }
        });

        buttonRosnaco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (czyMamyWyniki()) {
                    sortujRosnaco();
                }
            }
        });

        buttonMalejaco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (czyMamyWyniki()) {
                    sortujMalejaco();
                }
            }
        });
    }


    private boolean czyMamyWyniki() {
        if (listaWynikow.isEmpty()) {
            Toast.makeText(MainActivity.this, "Najpierw wykonaj losowanie kostek!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


    private void wykonajLosowanie() {
        String input = editTextLiczbaKostek.getText().toString().trim();

        if (input.isEmpty()) {
            Toast.makeText(this, "Błędne dane! Wprowadź liczbę.", Toast.LENGTH_SHORT).show();
            return;
        }

        int liczbaKostek;
        try {
            liczbaKostek = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Błędne dane! Podaj poprawną liczbę całkowitą.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (liczbaKostek <= 0) {
            Toast.makeText(this, "Nieprawidłowa liczba! Musi być większa od zera.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (liczbaKostek > 100) {
            Toast.makeText(this, "Przekroczono maksymalną liczbę kostek (maks. 100)!", Toast.LENGTH_SHORT).show();
            return;
        }


        listaWynikow.clear();


        for (int i = 0; i < liczbaKostek; i++) {
            int oczka = random.nextInt(6) + 1;
            listaWynikow.add(oczka);
        }

        odswiezWidokAplikacji();
    }

    private void sortujRosnaco() {
        int n = listaWynikow.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (listaWynikow.get(j) > listaWynikow.get(j + 1)) {
                    int temp = listaWynikow.get(j);
                    listaWynikow.set(j, listaWynikow.get(j + 1));
                    listaWynikow.set(j + 1, temp);
                }
            }
        }
        odswiezWidokAplikacji();
    }

    private void sortujMalejaco() {
        int n = listaWynikow.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (listaWynikow.get(j) < listaWynikow.get(j + 1)) {
                    int temp = listaWynikow.get(j);
                    listaWynikow.set(j, listaWynikow.get(j + 1));
                    listaWynikow.set(j + 1, temp);
                }
            }
        }
        odswiezWidokAplikacji();
    }

    private void odswiezWidokAplikacji() {

        StringBuilder sb = new StringBuilder();
        sb.append("Wyniki: ");
        for (int i = 0; i < listaWynikow.size(); i++) {
            sb.append(listaWynikow.get(i));
            if (i < listaWynikow.size() - 1) {
                sb.append(", ");
            }
        }
        textViewWyniki.setText(sb.toString());

        gridKostki.removeAllViews();
        gridKostki.setColumnCount(5);

        int margines = 10;
        int rozmiarKostki = 100;

        for (int wynik : listaWynikow) {
            ImageView tvKostka = new ImageView(this);
            tvKostka.setImageResource(image[wynik-1]);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = rozmiarKostki;
            params.height = rozmiarKostki;
            params.setMargins(margines, margines, margines, margines);
            tvKostka.setLayoutParams(params);

            gridKostki.addView(tvKostka);
        }
    }
}
