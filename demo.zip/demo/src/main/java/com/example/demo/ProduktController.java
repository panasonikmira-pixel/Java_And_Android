package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/produkty")
public class ProduktController {

    private final ProduktRepository produktRepository;

    public ProduktController(ProduktRepository produktRepository) {
        this.produktRepository = produktRepository;
    }

    // Pobieranie wszystkich produktów
    @GetMapping
    public List<Produkt> getAllProdukty() {
        return produktRepository.findAll();
    }

    // Pobieranie produktu po ID
    @GetMapping("/{id}")
    public Produkt getProduktById(@PathVariable Long id) {
        return produktRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Nie znaleziono produktu o ID: " + id));
    }

    // Dodawanie produktu
    @PostMapping
    public Produkt addProdukt(@RequestBody Produkt produkt) {
        return produktRepository.save(produkt);
    }

    // Usuwanie produktu
    @DeleteMapping("/{id}")
    public void deleteProdukt(@PathVariable Long id) {
        produktRepository.deleteById(id);
    }
}