package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.util.List;

public interface ProduktRepository extends JpaRepository<Produkt, Long> {
    List<Produkt> findByCenaLessThan(BigDecimal cena);
}