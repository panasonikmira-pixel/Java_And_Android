package com.example.rejestracja;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    private EditText imie;
    private EditText nazwisko;
    private EditText email;
    private EditText haslo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imie = findViewById(R.id.Imie);
        nazwisko = findViewById(R.id.Nazwisko);
        email = findViewById(R.id.Email);
        haslo = findViewById(R.id.Haslo);
        Button zarejestruj = findViewById(R.id.Zarejestruj);

        zarejestruj.setOnClickListener(v -> {
            String imieText = imie.getText().toString().trim();
            String nazwiskoText = nazwisko.getText().toString().trim();
            String emailText = email.getText().toString().trim();
            String hasloText = haslo.getText().toString().trim();

            if (checkForm(imieText, nazwiskoText, emailText, hasloText)) {
                pokazKomunikat("Dane poprawne", Toast.LENGTH_SHORT);
                saveToFile(imieText, nazwiskoText, emailText);
            }
        });
    }

    private boolean checkForm(String imie, String nazwisko, String email, String haslo) {
        if (checkValues(imie, nazwisko, email, haslo)) {
            pokazKomunikat("Uzupełnij wszystkie pola", Toast.LENGTH_SHORT);
            return false;
        }
        if (!checkEmail(email)) {
            pokazKomunikat("Podaj poprawny adres email", Toast.LENGTH_SHORT);
            return false;
        }
        if (!checkPassword(haslo)) {
            pokazKomunikat("Hasło musi mieć co najmniej 8 znaków, Dużą i Małą literę oraz znak specjalny", Toast.LENGTH_LONG);
            return false;
        }
        return true;
    }

    private boolean checkValues(String imie, String nazwisko, String email, String haslo) {
        return imie.isEmpty() || nazwisko.isEmpty() || email.isEmpty() || haslo.isEmpty();
    }

    private boolean checkEmail(String email) {
        return email.contains("@") && email.contains(".");
    }

    private boolean checkPassword(String haslo) {
        boolean maOdpowiedniaDlugosc = haslo.length() >= 8;
        boolean maDuzaLitere = haslo.matches(".*[A-Z].*");
        boolean maMalaLitere = haslo.matches(".*[a-z].*");
        boolean maZnakSpecjalny = haslo.matches(".*[!@#$%^&*()_+{}?;':<>,./\\\\=\\-].*");
        return maOdpowiedniaDlugosc && maDuzaLitere && maMalaLitere && maZnakSpecjalny;
    }

    private void pokazKomunikat(String tekst, int dlugosc) {
        Toast.makeText(MainActivity.this, tekst, dlugosc).show();
    }

    private void saveToFile(String name, String surname, String emailStr) {
        String text = "Imie: " + name + "\n" + "Nazwisko: " + surname + "\n" + "Email: " + emailStr + "\n";

        try {
            FileOutputStream fos = openFileOutput("dane.txt", MODE_PRIVATE);
            fos.write(text.getBytes());
            fos.close();
            pokazKomunikat("zapisano", Toast.LENGTH_SHORT);

        } catch (Exception e) {
            e.printStackTrace();
            pokazKomunikat("nie zapisano", Toast.LENGTH_SHORT);
        }
    }
}
