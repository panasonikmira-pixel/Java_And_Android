import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void wypTab(int[] tab, int n) {
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            tab[i] = random.nextInt(100) + 1;
        }
    }

    public static int SzukWart(int[] tab, int n, int szuk) {
        tab[n] = szuk;
        int i = 0;
        while (tab[i] != szuk) {
            i++;
        }
        if (i == n) {
            return -1;
        }
        return i;
    }

    public static void main(String[] args) {
        int maxrozm = 50;
        int[] tab = new int[maxrozm + 1];
        wypTab(tab, maxrozm);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj liczbe(1-100): ");
        int szuk = scanner.nextInt();

        int indeks = SzukWart(tab, maxrozm, szuk);
        System.out.println("Zawartosc tablicy");

        if (maxrozm > 0) {
            System.out.print(tab[0]);
            for (int i = 1; i < maxrozm; i++) {
                System.out.print(", " + tab[i]);
            }
        }
        if (indeks != -1) {
            System.out.println("Wartosc znaleziono" + szuk + " pod indeksem: " + indeks);
        } else {
            System.out.println("Wartosc" + szuk + "nie wystepuje");
        }

        scanner.close();
    }
}

